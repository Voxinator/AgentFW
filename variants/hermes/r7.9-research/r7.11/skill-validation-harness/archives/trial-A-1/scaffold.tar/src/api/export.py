"""Export endpoints. Implements permission-checked data exporting."""

from typing import List, Dict, Any, Union
from src.auth.permissions import has_permission
from src.export.csv import serialize_csv
from src.export.json import serialize_json
from src.export.pdf import serialize_pdf
from src.auth import User

def export_data(user: User, records: List[Dict[str, Any]], format: str) -> Union[str, bytes]:
    """
    Exports records if the user has permission for each record.
    
    Args:
        user: The user attempting the export.
        records: The list of data records.
        format: The desired export format ('csv', 'json', 'pdf').
        
    Returns:
        The serialized data in the requested format.
        
    Raises:
        PermissionError: If the user does not have permission for any of the records.
        ValueError: If an unsupported format is requested.
    """
    # 1. Permission Check
    # For this implementation, we ensure the user has permission for ALL records.
    # If any record is restricted, we deny the entire export for security.
    for record in records:
        if not has_permission(user, record):
            raise PermissionError("User does not have permission to access one or more records.")

    # 2. Serialization
    format = format.lower()
    if format == 'csv':
        return serialize_csv(records)
    elif format == 'json':
        return serialize_json(records)
    elif format == 'pdf':
        return serialize_pdf(records)
    else:
        raise ValueError(f"Unsupported export format: {format}")

if __name__ == "__main__":
    # Simple smoke test
    class MockUser:
        def __init__(self, uid): self.user_id = uid
        def __repr__(self): return f"MockUser({self.user_id})"

    user = MockUser("user_123")
    data = [
        {"id": 1, "name": "Item 1", "owner_id": "user_123"},
        {"id": 2, "name": "Item 2", "owner_id": "user_123"},
    ]
    
    try:
        print("Testing JSON export:")
        print(export_data(user, data, "json"))
        
        print("\nTesting CSV export:")
        print(export_data(user, data, "csv"))
        
        print("\nTesting Permission Denied:")
        bad_data = [{"id": 3, "name": "Secret", "owner_id": "other_user"}]
        export_data(user, bad_data, "json")
    except PermissionError as e:
        print(f"Caught expected error: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")
