"""Export endpoints. Populated by capability-curve trials."""

from src.auth import User, get_current_user
from src.auth.permissions import has_permission, has_permission_for_many

def export_records(records: list[dict]) -> dict:
    """
    API endpoint to export records.
    Ensures the current user has permission to access each record.
    """
    user = get_current_user()
    
    # Use the batch permission function to satisfy the wiring requirement
    authorized_records = has_permission_for_many(user, records)
    
    return {
        "user_id": user.user_id,
        "count": len(authorized_records),
        "data": authorized_records
    }
